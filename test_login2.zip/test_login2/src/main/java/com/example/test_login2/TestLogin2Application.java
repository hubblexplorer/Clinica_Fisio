package com.example.test_login2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestLogin2Application {
	//https://www.javaguides.net/2018/10/user-registration-module-using-springboot-springmvc-springsecurity-hibernate5-thymeleaf-mysql.html
	public static void main(String[] args) {
		SpringApplication.run(TestLogin2Application.class, args);
	}

}
